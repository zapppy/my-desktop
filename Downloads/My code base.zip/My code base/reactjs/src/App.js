import React, {Component} from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Todos from './components/Todos';
import './App.css';
import Header from './components/Layout/Header';
import AddTodo from './components/AddTodo';
import uuid from 'uuid'
import About from './components/Pages/About';
//import axios from 'axios';

export default class App extends Component { 
    state = {
      todos: [
        /*{
          id: uuid.v4(),
          task:'Do the cleaning',
          isCompleted:false,
        },
        {
          id: uuid.v4(),
          task:'Anniversary night',
          isCompleted:false, 
        },
        {
          id: uuid.v4(),
          task:'Long drive',
          isCompleted:false,
        },*/
     ]
   }

   /*componentDidMount(){
     axios.get('https://jsonplaceholder.typicode.com/todos?_limit=10')
      .then( res => this.setState({ todos: res.data}))
   }*/

  markComplete = (id) => {
    this.setState({todos: this.state.todos.map(todo => {
      if(todo.id===id){
          todo.completed = !todo.completed
          //console.log(todo.isCompleted)
      }
      return todo;
    })  });
};

  markDeleted = (id) => {
    this.setState({todos: [...this.state.todos.filter(todo => todo.id!==id)]
    })  
    //console.log(id)
};

  addTodo = (title) => {
    const newTodo = {
      id: uuid.v4(),
      title ,
      completed: false,
    }
    //axios.post('https://jsonplaceholder.typicode.com/todos', 
    this.setState({todos: [...this.state.todos, newTodo]})
      //.then( res => this.setState({todos: [...this.state.todos, res.data]}))
  //console.log(title)
};

  render(){ 
    return ( 
      <Router>  
        <div className = 'App'>
          <div className = 'container'>
            <Header />
            <Route exact path = "/" render = { props => (
              <React.Fragment>
                <AddTodo addTodo = {this.addTodo}/>
                <Todos todos = {this.state.todos} markComplete = {this.markComplete} 
                markDeleted = {this.markDeleted}/> 
              </React.Fragment>  
            )}/>
            <Route path = "/about" component = {About}/>
          </div>
        </div>
      </Router> 
    );
  }
}


