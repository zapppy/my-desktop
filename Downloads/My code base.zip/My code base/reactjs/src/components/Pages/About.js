import React from 'react'

export default function About() {
    return (
        <React.Fragment>
            <h1>About</h1>
            <p>This is the TodoList App V1.0.0. It is made by Saikat Saha </p>
        </React.Fragment>
    )
}
