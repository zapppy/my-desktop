import React, { Component } from 'react'

export default class AddTodo extends Component {

    state = {
        title: ''
    }


    //onChange = (e) => this.setState({ titile: e.target.value}) // for single state component
    onChange = (e) => this.setState({ [e.target.name]: e.target.value}) //for multiple state component, given the name field is same for all of the entries 

    onSubmit = (e) => {
        e.preventDefault();
        this.props.addTodo(this.state.title);
        this.setState({ title: ''});
    }


    render() {
        return (
            <div>
                <form onSubmit = {this.onSubmit} style = {{ display : 'flex'}}>  
                    <input 
                    className = 'addtodo'
                    type = "text"
                    name = "title"
                    placeholder = "Add Todo..."
                    style = {{ flex : '10', padding : '5px' }}
                    value = {this.state.title}
                    onChange = {this.onChange}
                    />
                    <input 
                    className = 'btn'
                    type = "submit"
                    value = "submit"
                    style = {{ flex : '1'}}
                    />
                </form>
            </div>
        )
    }
}

