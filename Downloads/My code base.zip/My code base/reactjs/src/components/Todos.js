import React, { Component } from 'react';
import Todoitem from './Todoitem';
import Proptypes from 'prop-types';


export default class Todos extends Component {
  /*markComplete = (e) => {
    console.log('Hello')
  }*/
  render(){
    return this.props.todos.map((todo) =>   
    <Todoitem key = {todo.id} todo = {todo} markComplete = {this.props.markComplete}
      markDeleted = {this.props.markDeleted}/>
    )
  }
}

//Proptypes
Todos.propTypes = {
  todos: Proptypes.array.isRequired
}


