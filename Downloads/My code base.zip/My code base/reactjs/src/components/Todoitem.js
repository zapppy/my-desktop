import React, { Component } from 'react';
import PropTypes from 'prop-types';



export default class Todoitem extends Component {
  getStyle = () =>{
    return{
      backgroundColor : 'coral',
      borderBottom: '1px solid blue',
      padding: '10px',
      textDecoration : this.props.todo.completed ? 'line-through' : 'none',
    }
  }
  render(){
    const { id, title } = this.props.todo
    return ( 
      <div style = {this.getStyle()}>
         <p>
           <input 
            type = "checkbox" 
            onChange = {this.props.markComplete.bind(this, id)}
           /> 
           {'  '}
           {title}    
           <button 
           onClick = {this.props.markDeleted.bind(this, id)} 
           style = {btnstyle}>X</button> 
           
          </p>
      </div>
    );
  }
}

const btnstyle = {
  backgroundColor : 'red',
  textColor : 'white',
  padding : '1px',
  borderRadius : '50%',
  float : 'right',
  cursor : 'pointer',
}
//Proptypes
Todoitem.propTypes = {
    todo: PropTypes.object.isRequired
  }

