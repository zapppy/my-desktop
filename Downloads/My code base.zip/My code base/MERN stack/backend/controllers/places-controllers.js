const HttpError = require('../models/http-error');

const uuid = require('uuid/v4');

const DUMMY_PLACES = [{
    id: 'p1',
    creatorID: '1',
    address: '1 Sheikh Mohammed bin Rashid Blvd - Dubai - United Arab Emirates',
    description: 'The tallest builduing',
    title: 'Arabian oasiss',
    location: {
        lat: 25.1972162,
        lng: 55.2656216
    },
}];

const getPlaceById = (req,res,next)=>{
    const placeId = req.params.pid;
    const places = DUMMY_PLACES.find(p => {
        return p.id === placeId;
    })

    if(!places){
           throw new HttpError('Could not get the place details', 404);
    }

    res.json({places})
};

const getUserPlaceById = (req,res,next)=>{
    const userId = req.params.uid;
    const place = DUMMY_PLACES.find(p => {
        return p.creatorID === userId;
    })

    if(!place){
        return next(
            new HttpError('Could not get the user places details', 404)
            );
    }

    res.json({place});
};
 
const createPlaces = ((req,res,next) => {
    const { id, title, description, address, location, creator } = req.body;

    const createdPlace = {
        id: uuid(),
        title,
        description,
        address,
        location,
        creatorID: creator
    };
    DUMMY_PLACES.push(createdPlace);
    res.status(201).json({place: createdPlace});
});

exports.getPlaceById = getPlaceById;
exports.getUserPlaceById = getUserPlaceById;
exports.createPlaces = createPlaces;