const express = require('express');

const userRouter = express.Router();

const USERS = [
    {
    id : '1',
    name: 'Saikat Saha',
    placeCount: '3'
}];

userRouter.get('/:uid',(req,res,next) => {
    const userId = req.params.uid;
    const Users = USERS.find(p => {
        return p.id === userId;
    })
    res.json({Users})
});

module.exports = userRouter;