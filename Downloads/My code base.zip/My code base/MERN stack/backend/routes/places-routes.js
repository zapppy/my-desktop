const express = require('express');

const placesControllers = require('../controllers/places-controllers');

const router = express.Router();


router.get('/:pid', placesControllers.getPlaceById);

router.get('/users/:uid', placesControllers.getUserPlaceById);

router.post('/', placesControllers.createPlaces);

router.patch('/:pid',placesControllers.getPlaceById);

module.exports = router;