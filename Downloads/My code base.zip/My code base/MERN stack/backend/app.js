const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const HttpError = require('./models/http-error');

const placeRoutes = require('./routes/places-routes');
//const userRoutes = require('./routes/user-routes');

app.use(bodyParser.json());

app.use('/api/places',placeRoutes);

app.use((res,req,next) => {
    const error = new HttpError('Could not get the routes', 404);
    throw error;
});

app.use((error,req,res,next) => {
    if(res.headerSent){
        return next(error);
    }
    res.status(error.code||500);
    res.json({message: error.message||'An unknown error occured!'});
});

//app.use('/users',userRoutes)

app.listen(5000);