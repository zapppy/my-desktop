const express = require('express');

const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended : false }));

app.post('/users', (req,res,next) => {
    return res.send('<h1>' + req.body.userName + '</h1>');
});

app.get('/',(req,res,next) => {
    res.send('<form action = "/users" method = "POST"><input type = "text" name = "userName"><button type = "submit">Create User</button></form>')
});

app.listen(5000);