import React, {useState, useCallback} from 'react';

import Users from './user/pages/Users';
import NewPlaces from './places/pages/NewPlaces';
import Userplaces from './places/pages/Userplaces';
import UpdatePlace from './places/pages/UpdatePlace';
import Auth from './user/pages/Auth';
import { BrowserRouter as Router, Route, Redirect, Switch} from 'react-router-dom';
import MainNavigation from './shared/components/Navigation/MainNavigation';
import { AuthContext } from './shared/context/auth-context';


export default function App() {

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const login = useCallback(() =>{
    setIsLoggedIn(true)
  },[]);

  const logout = useCallback(() =>{
    setIsLoggedIn(false)
  },[]);

  let routes;

  if(isLoggedIn){
    routes = (
      <Switch>
        <Route exact path = "/">
          <Users />
        </Route>
        <Route exact path = "/:userID/places">
          <Userplaces />
        </Route>  
        <Route exact path ="/places/new">
          <NewPlaces />   
        </Route>  
        <Route exact path ="/places/:placeId">
          <UpdatePlace />        
        </Route>
        <Redirect to = "/"/>
      </Switch>
    );
  }
  else {
    routes = (
      <Switch>
        <Route exact path = "/">
          <Users />
        </Route>
        <Route exact path = "/:userID/places">
          <Userplaces />
        </Route>
        <Route exact path ="/users/new">
          <Auth />        
        </Route>
        <Redirect to = "/users/new"/>
      </Switch>
    )
  }

  return (
    <AuthContext.Provider 
      value= {{isLoggedIn: isLoggedIn, login: login, logout: logout}}
    >
      <Router>
        <MainNavigation />
          <main>{routes}</main>
      </Router>
    </AuthContext.Provider>
  );
};
