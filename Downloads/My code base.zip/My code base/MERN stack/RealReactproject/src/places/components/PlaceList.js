import React from 'react'

import PlaceItem from './PlaceItem'
import Card from '../../shared/components/UIElements/Card'
import Button from '../../shared/components/FormElements/Button'
import './PlaceList.css'

export default function PlaceList(props) {

    if (props.items.length === 0 ){
        return (
        <div className = "place-list center">
            <Card className = "card">
            <h2> No places found. Maybe create one?</h2> 
            <Button to ="/places/new">  Share Place  </Button>         
            </Card>
        </div>
        )
    };

    return (
        <ul className = "place-list">
        {props.items.map(list => (
            <PlaceItem 
            key = {list.id}
            id = {list.id}
            title = {list.title}
            creatorID = {list.creatorID}
            image = {list.imgurl}
            address = {list.address}
            description = {list.description}
            coordinates = {list.location}
            />
            ))}
        </ul>
    )
}
