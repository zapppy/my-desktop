import React from 'react';

import { useForms } from '../../shared/hooks/FormHooks';
import Input from '../../shared/components/FormElements/Input';
import { VALIDATOR_REQUIRE, VALIDATOR_MINLENGTH } from '../../shared/util/Validators';
import Button from '../../shared/components/FormElements/Button';
import './PlaceForm.css';

export default function NewPlaces() {

    const [formState, inputHandeler] = useForms({
        title:{
            value: '',
            isValid: false
        },
        description:{
            value: '',
            isValid: false
        },
        address:{
            value: '',
            isValid: false
        }
    },
    false
    );

    const formSubmitHandeler = (e) =>{
        e.preventDefault();
        console.log(formState.inputs)
    }

    return (
        <form className =  "place-form" onSubmit = { formSubmitHandeler }>
        <Input 
        id = "title"
        element = "input" 
        type = "text" 
        label = "Title"  
        //placeholder = "Enter the title"
        onInput = {inputHandeler}
        validators = {[VALIDATOR_REQUIRE()]}
        errorText = "Enter the text" /> 

        <Input 
        id = "description"
        element = "textarea" 
        type = "textarea" 
        label = "Description" 
        onInput = {inputHandeler}
        validators = {[VALIDATOR_MINLENGTH(5)]}
        errorText = "Enter the description (minimum 5 letters)" />   

        <Input 
        id = "address"
        element = "input" 
        type = "text" 
        label = "Address" 
        onInput = {inputHandeler}
        validators = {[VALIDATOR_REQUIRE()]}
        errorText = "Enter the address" />  

        <Button type = "submit" disabled = {!formState.isValid}>ADD PLACE</Button> 
        </form>
    )
}
