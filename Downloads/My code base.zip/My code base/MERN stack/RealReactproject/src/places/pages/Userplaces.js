import React from 'react';

import { useParams } from "react-router-dom";
import PlacesList from '../components/PlaceList';

const PLACES = [
    {
        id: 'p1',
        creatorID: '1',
        imgurl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRLXlsal_SjJPQDOres0ah4qULU41K10y9gcs4sGqCsfRIOMA7y',
        address: '1 Sheikh Mohammed bin Rashid Blvd - Dubai - United Arab Emirates',
        description: 'The tallest builduing',
        title: 'Arabian oasis',
        location: {
            lat: 25.1972162,
            lng: 55.2656216
        },
    },

    {
        id: 'p2',
        creatorID: '2',
        imgurl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRwENCF_KgGFVvcQ7HQdvqW0ivPJAyCZYL0TNJHLTgWV1fAHr_D',
        address: 'Dharmapuri, Forest Colony, Tajganj, Agra, Uttar Pradesh 282001',
        description: 'The Indian heritage',
        title: 'Memorial of love',
        location: {
            lat: 27.1751636,
            lng: 78.0333874
        },
    }




]

export default function Userplaces() {
    const userID = useParams().userID;
    const localeplaces = PLACES.filter(places => places.creatorID === userID);

    return (
         
        <div>
            <PlacesList items = {localeplaces}/>
        </div>
    )
}
