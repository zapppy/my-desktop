import React,{ useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import {} from '../../shared/util/Validators';
import Input from '../../shared/components/FormElements/Input';
import Button from '../../shared/components/FormElements/Button';
import { VALIDATOR_REQUIRE, VALIDATOR_MINLENGTH } from '../../shared/util/Validators';
import Card from '../../shared/components/UIElements/Card';
import { useForms } from '../../shared/hooks/FormHooks';

import './PlaceForm.css';

const PLACES = [
    {
        id: 'p1',
        creatorID: '1',
        imgurl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRLXlsal_SjJPQDOres0ah4qULU41K10y9gcs4sGqCsfRIOMA7y',
        address: '1 Sheikh Mohammed bin Rashid Blvd - Dubai - United Arab Emirates',
        description: 'The tallest builduing',
        title: 'Arabian oasis',
        location: {
            lat: 25.1972162,
            lng: 55.2656216
        },
    },

    {
        id: 'p2',
        creatorID: '2',
        imgurl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRwENCF_KgGFVvcQ7HQdvqW0ivPJAyCZYL0TNJHLTgWV1fAHr_D',
        address: 'Dharmapuri, Forest Colony, Tajganj, Agra, Uttar Pradesh 282001',
        description: 'h Indian heritage',
        title: 'Memorial of love',
        location: {
            lat: 27.1751636,
            lng: 78.0333874
        },
    }
]

export default function UpdatePlace() {

    const [isLoading, setIsLoading] = useState(false);

    const placeId = useParams().placeId;

    const [formState, inputHandeler, setFormData] = useForms({
        title:{
            value: '',
            isValid: false
        },
        description:{
            value: '',
            isValid: false
        },
    },    
    false
    );

    const indentifiedPlace = PLACES.find(p => p.id === placeId);

    useEffect(() =>{
        if(indentifiedPlace) {
            setFormData(
                {
                    title:{
                    value: indentifiedPlace.title,
                    isValid: true
                    },
                     description:{
                    value: indentifiedPlace.description,
                    isValid: true
                    },
                },
                true,
            );
        }
        setIsLoading(true);
    },
    [setFormData, indentifiedPlace]
    );
    

    const formSubmitHandeler = (e) =>{
        e.preventDefault();
        console.log(formState.inputs)
    }

    if(!indentifiedPlace){
        return(
            <div className = "center"> 
                <Card >
                    <h2>Coudn't find a place!</h2> 
                    <Button> Share Place </Button>
                </Card>
            </div>
        )
    }

    if(!isLoading){
        return(
        <div className = "center"> Loading.... </div>
        )
    }

    return (
        <form className = "place-form" onSubmit = {formSubmitHandeler}>

            <Input 
            id = "title" 
            element = "input" 
            type = "text" 
            label = "Title" 
            validators = {[VALIDATOR_REQUIRE()]}
            onInput = {inputHandeler}
            errorText = "Enter the text"
            initialValue = {formState.inputs.title.value}
            initialIsValid = {formState.inputs.title.isValid}
            />
            
            <Input 
            id = "description" 
            element = "textarea" 
            label = "Description" 
            validators = {[VALIDATOR_MINLENGTH(5)]}
            onInput = {inputHandeler}
            errorText = "Enter the description (min. 5 letters)"
            initialValue = {formState.inputs.description.value}
            initialIsValid = {formState.inputs.description.isValid}
            />

            <Button type = "sumbit" disabled = {!formState.isValid}> UPDATE PLACE </Button>
        </form>
    )
}
