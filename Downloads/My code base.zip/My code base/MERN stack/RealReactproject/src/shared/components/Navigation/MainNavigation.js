import React, { useState} from 'react'

import { Link } from 'react-router-dom';
import MainHeader from './MainiHeader';
import './MainNavigation.css';
import NavLink from './NavLinks';
import SideDrawer from './SideDrawer';
import BackDrop from '../UIElements/BackDrop';

export default function MainNavigation() {
    const [drawerStatus, setDrawerStatus] = useState(false);

    const openDrawer = () =>{
        setDrawerStatus(true);
    }

    const closeDrawer = () =>{
        setDrawerStatus(false);
    }

    return (
        <React.Fragment>
        {drawerStatus && <BackDrop onClick = {closeDrawer}/>}    
        <SideDrawer show = {drawerStatus} onClick = {closeDrawer}>
            <nav className = "main-navigation__drawer-nav"> 
                <NavLink />    
            </nav>
        </SideDrawer>

        <MainHeader>
            <button className = "main-navigation__menu-btn" onClick = {openDrawer}>
            <span />
            <span />
            <span />
            </button>
            <h1 className = "main-navigation__title"> 
                <Link to = "/"> Your Places </Link>
            </h1>
            <nav className = "main-navigation__header-nav" >
                <NavLink />
            </nav>
        </MainHeader>
        </React.Fragment>
    )
}
