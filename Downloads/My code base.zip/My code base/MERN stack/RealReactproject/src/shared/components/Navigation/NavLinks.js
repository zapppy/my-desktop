import React, {useContext} from 'react';

import { NavLink } from 'react-router-dom';
import './NavLinks.css';
import { AuthContext } from '../../context/auth-context';
import Button from '../FormElements/Button';

//Sconst userID = useParams().userID;

export default function NavLinks() {

    const auth = useContext(AuthContext);

    return (
        <ul className = "nav-links">    
            <li>
                <NavLink to = "/" exact> All Users </NavLink>
            </li>
            {auth.isLoggedIn && (
            <li>    
                <NavLink to = "/1/places" > My Places </NavLink>
            </li>)}
            {auth.isLoggedIn && (
            <li>    
                <NavLink to = "/places/new" exact> New Places </NavLink>
            </li>)}
            {!auth.isLoggedIn && (
            <li>
                <NavLink to = "/users/new" exact> Authenticate </NavLink>
            </li>)}
            {auth.isLoggedIn && (
            <li>
                <Button onClick = {auth.logout}> LOGOUT </Button>          
            </li>)                
            }
        </ul>   
    );
}
