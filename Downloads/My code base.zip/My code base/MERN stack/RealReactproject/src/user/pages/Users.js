import React from 'react';

import UserList from '../components/UserList';

const USERS = [
    {
    image: 'https://previews.123rf.com/images/pixelae/pixelae1612/pixelae161200009/68974872-red-triangle-caution-warning-alert-sign-vector-illustration-isolated-on-white-background-be-careful-.jpg',
    id : '1',
    name: 'Saikat Saha',
    placeCount: '3'
},

{
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTFwS_ED7PMLjZfPqy-WvNNWvxXyBLUV9JXkv8nZpPqhgzHiE5e',
    id : '2',
    name: 'Anamika Guha',
    placeCount: '2'
}
];

export default function Users() {


    return (
        <UserList items  = {USERS}/>      
    );
}


