import React, { useState, useContext } from 'react';

import { useForms } from '../../shared/hooks/FormHooks';
import Input from '../../shared/components/FormElements/Input';
import { VALIDATOR_EMAIL, VALIDATOR_MINLENGTH, VALIDATOR_REQUIRE } from '../../shared/util/Validators';
import Button from '../../shared/components/FormElements/Button';
import Card from '../../shared/components/UIElements/Card';
import { AuthContext } from '../../shared/context/auth-context';

import './Auth.css';

export default function Auth() {

    const auth = useContext(AuthContext);

    const [isSwitchMode, setIsSwitchMode] = useState(false);


    const [formState, inputHandeler, setState] = useForms({

        email:{
            value: '',
            isValid: false
        },
        password:{
            value: '',
            isValid: false
        }
    },
    false
    );

    const switchModeHandeler = () =>{
        console.log(formState.isValid);

        if(isSwitchMode){
            setState({
                ...formState.inputs,
                name: undefined
            },(formState.inputs.email.isValid && formState.inputs.password.isValid))
        }

        else{
            setState({
                ...formState.inputs,
                name: {
                    value: '',
                    isValid: false
                }
            },false)
        }

        setIsSwitchMode(prevState => !prevState); 
    }

    const formSubmitHandeler = (e) =>{
        e.preventDefault();
        console.log(formState.inputs);
       
        auth.login();
    }

    return (
        <Card className = "authentication">
            <h2>Login Required</h2>
            <hr />
            <form  onSubmit = { formSubmitHandeler }>
                
                {isSwitchMode && 
                <Input 
                id = "name"
                element = "input" 
                type = "text" 
                label = "Your name"  
                onInput = {inputHandeler}
                validators = {[VALIDATOR_REQUIRE()]}
                errorText = "Enter your name"
                />
                }

                <Input 
                    id = "email"
                    element = "input" 
                    type = "email" 
                    label = "Email"  
                    onInput = {inputHandeler}
                    validators = {[VALIDATOR_EMAIL()]}
                    errorText = "Enter a valid Email Address"
                    /> 

                <Input 
                    id = "password"
                    element = "input" 
                    type = "text" 
                    label = "Password" 
                    onInput = {inputHandeler}
                    validators = {[VALIDATOR_MINLENGTH(8)]}
                    errorText = "Enter the password (minimum 8 letters)"
                    />   

                <Button 
                    type = "submit" 
                    disabled = {!formState.isValid}
                    >{!isSwitchMode ? 'LOGIN':'SIGN UP'} 
                </Button> 
            </form>
            <Button 
                    inverse
                    onClick = {switchModeHandeler}
                    >SWITCH TO {isSwitchMode? 'LOGIN': 'SIGN UP'}
                </Button> 
        </Card>
    )
}

